import os
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, executor, types

# Load environment variables
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

# Import plugins
from plugins import ai_module, music_player, welcome, moderation, auto_reply, vote_system, translator

ai_module.register_handlers(dp, ADMIN_ID, OPENAI_API_KEY)
music_player.register_handlers(dp)
welcome.register_handlers(dp)
moderation.register_handlers(dp, ADMIN_ID)
auto_reply.register_handlers(dp)
vote_system.register_handlers(dp)
translator.register_handlers(dp)

@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer("سلام! ربات پیشرفته فعال شد. از دستورات استفاده کن.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
